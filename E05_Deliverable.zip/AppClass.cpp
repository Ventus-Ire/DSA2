#include "AppClass.h"
void Application::InitVariables(void)
{
	//init the mesh
	m_pMesh = new MyMesh();
	//m_pMesh->GenerateCube(1.0f, C_WHITE);
	m_pMesh->GenerateCube(1.0f, C_BLACK);
	
	mesh2 = new MyMesh();
	mesh2->GenerateCube(1.0f, C_BLACK);
	
	mesh3 = new MyMesh();
	mesh3->GenerateCube(1.0f, C_BLACK);
	
	mesh4 = new MyMesh();
	mesh4->GenerateCube(1.0f, C_BLACK);
	
	mesh5 = new MyMesh();
	mesh5->GenerateCube(1.0f, C_WHITE);

	mesh6 = new MyMesh();
	mesh6->GenerateCube(1.0f, C_BLACK);

	mesh7 = new MyMesh();
	mesh7->GenerateCube(1.0f, C_BLACK);

	mesh8 = new MyMesh();
	mesh8->GenerateCube(1.0f, C_WHITE);

	mesh9 = new MyMesh();
	mesh9->GenerateCube(1.0f, C_BLACK);

	mesh10 = new MyMesh();
	mesh10->GenerateCube(1.0f, C_BLACK);

	mesh11 = new MyMesh();
	mesh11->GenerateCube(1.0f, C_BLACK);

	mesh12 = new MyMesh();
	mesh12->GenerateCube(1.0f, C_BLACK);

}
void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the arcball active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();
}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();

	matrix4 m4View = m_pCameraMngr->GetViewMatrix();
	matrix4 m4Projection = m_pCameraMngr->GetProjectionMatrix();
	static float value = 0.0f;
	value += 0.01f;
	matrix4 m4Scale = glm::scale(IDENTITY_M4, vector3(1.0f,1.0f,1.0f));
	
	matrix4 m4Translate = glm::translate(IDENTITY_M4, vector3(1.0f + value, 0.0f, 0.0f));
	matrix4 t2 = glm::translate(IDENTITY_M4, vector3(2.0f + value, 0.0f, 0.0f));
	matrix4 t3 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 0.0f, 0.0f));
	matrix4 t4 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 1.0f, 0.0f));
	matrix4 t5 = glm::translate(IDENTITY_M4, vector3(2.0f + value, 1.0f, 0.0f));
	matrix4 t6 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 1.0f, 0.0f));
	matrix4 t7 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 2.0f, 0.0f));
	matrix4 t8 = glm::translate(IDENTITY_M4, vector3(2.0f + value, 2.0f, 0.0f));
	matrix4 t9 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 2.0f, 0.0f));
	matrix4 t10 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 3.0f, 0.0f));
	matrix4 t11 = glm::translate(IDENTITY_M4, vector3(2.0f + value, 3.0f, 0.0f));
	matrix4 t12 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 3.0f, 0.0f));
	

	//matrix4 m4Model = m4Translate * m4Scale;
	matrix4 m4Model = m4Scale * m4Translate;
	matrix4 m2 = m4Scale * t2;
	matrix4 m3 = m4Scale * t3;
	matrix4 m4 = m4Scale * t4;
	matrix4 m5 = m4Scale * t5;
	matrix4 m6 = m4Scale * t6;
	matrix4 m7 = m4Scale * t7;
	matrix4 m8 = m4Scale * t8;
	matrix4 m9 = m4Scale * t9;
	matrix4 m10 = m4Scale * t10;
	matrix4 m11 = m4Scale * t11;
	matrix4 m12 = m4Scale * t12;

	m_pMesh->Render(m4Projection, m4View, m4Model);
	mesh2->Render(m4Projection, m4View, m2);
	mesh3->Render(m4Projection, m4View, m3);
	mesh4->Render(m4Projection, m4View, m4);
	mesh5->Render(m4Projection, m4View, m5);
	mesh6->Render(m4Projection, m4View, m6);
	mesh7->Render(m4Projection, m4View, m7);
	mesh8->Render(m4Projection, m4View, m8);
	mesh9->Render(m4Projection, m4View, m9);
	mesh10->Render(m4Projection, m4View, m10);
	mesh11->Render(m4Projection, m4View, m11);
	mesh12->Render(m4Projection, m4View, m12);
	
	// draw a skybox
	m_pMeshMngr->AddSkyboxToRenderList();
	
	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();
	
	//draw gui
	DrawGUI();
	
	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	SafeDelete(m_pMesh);

	//release GUI
	ShutdownGUI();
}