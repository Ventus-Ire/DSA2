#include "AppClass.h"
#include <iostream>
using namespace std;

vector<vector<vector3>> listListVectors; // for storing a list of lists of vectors
void Application::InitVariables(void)
{
	//Change this to your name and email
	m_sProgrammer = "Amit Nemani - akn7003@g.rit.edu";
	
	//m_pMesh = new MyMesh();
	//m_pMesh->GenerateCylinder(0.5f, 1.0f, 5, C_WHITE);

	//Set the position and target of the camera
	//(I'm at [0,0,10], looking at [0,0,0] and up is the positive Y axis)
	m_pCameraMngr->SetPositionTargetAndUp(AXIS_Z * 20.0f, ZERO_V3, AXIS_Y);

	//if the light position is zero move it
	if (m_pLightMngr->GetPosition(1) == ZERO_V3)
		m_pLightMngr->SetPosition(vector3(0.0f, 0.0f, 3.0f));

	//if the background is cornflowerblue change it to black (its easier to see)
	if (vector3(m_v4ClearColor) == C_BLUE_CORNFLOWER)
	{
		m_v4ClearColor = vector4(ZERO_V3, 1.0f);
	}
	
	//if there are no segments create 7
	if(m_uOrbits < 1)
		m_uOrbits = 7;

	float fSize = 1.0f; //initial size of orbits

	//creating a color using the spectrum 
	uint uColor = 650; //650 is Red
	//prevent division by 0
	float decrements = 250.0f / (m_uOrbits > 1? static_cast<float>(m_uOrbits - 1) : 1.0f); //decrement until you get to 400 (which is violet)
	/*
		This part will create the orbits, it start at 3 because that is the minimum subdivisions a torus can have
	*/
	uint uSides = 3; //start with the minimal 3 sides
	for (uint i = uSides; i < m_uOrbits + uSides; i++)
	{
		vector3 v3Color = WaveLengthToRGB(uColor); //calculate color based on wavelength
		m_shapeList.push_back(m_pMeshMngr->GenerateTorus(fSize, fSize - 0.1f, 3, i, v3Color)); //generate a custom torus and add it to the meshmanager
		vector<vector3> stopList;
		for (int j = 0; j < i; j++)
		{
			float x = ((fSize - .1f) * cosf(j * (2* PI) / i));
			float y = ((fSize - .1f) * sin(j * (2 * PI) / i));
			float z = 0;
			stopList.push_back(vector3(x, y, z));
		}
		listListVectors.push_back(stopList);
		routes.push_back(0);
		fSize += 0.5f; //increment the size for the next orbit
		uColor -= static_cast<uint>(decrements); //decrease the wavelength
	}
}
void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the arcball active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();
}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();


	matrix4 m4View = m_pCameraMngr->GetViewMatrix(); //view Matrix
	matrix4 m4Projection = m_pCameraMngr->GetProjectionMatrix(); //Projection Matrix
	matrix4 m4Offset = IDENTITY_M4; //offset of the orbits, starts as the global coordinate system

	//Generate a timer
	static double fTimer = 0.0;	//store the new timer
	static uint uClock = m_pSystem->GenClock(); //generate a new clock for that timer
	fTimer += m_pSystem->GetDeltaTime(uClock); //get the delta time for that timer
	/*
		The following offset will orient the orbits as in the demo, start without it to make your life easier.
	*/
	//m4Offset = glm::rotate(IDENTITY_M4, 1.5708f, AXIS_Z);
	
	// draw a shapes
	for (uint i = 0; i < m_uOrbits; i++)
	{
		m_pMeshMngr->AddMeshToRenderList(m_shapeList[i], glm::rotate(m4Offset, 1.5708f, AXIS_X));

		//calculate the current position
		vector3 v3CurrentPos = ZERO_V3;
		//keep track of the start and end vectors
		vector3 start;
		vector3 end;
		//go through each list of vector and check against their corresponding route
		if (routes[i] < listListVectors[i].size() - 1)
		{
			start = listListVectors[i][routes[i]];
			end = listListVectors[i][routes[i] + 1];
		}
		else
		{
			start = listListVectors[i][listListVectors[i].size() - 1];
			end = listListVectors[i][0];
		}

		//move the vectors and check against it's completion along the route
		float percentage = static_cast<float>(MapValue(fTimer, 0.0, 0.2, 0.0, 1.0));
		v3CurrentPos = glm::lerp(start, end, percentage);
		//increment each route number if the lerp has completed
		if (percentage >= 1.0f)
		{
			for (int j = 0; j < listListVectors.size(); j++)
			{
				routes[j] += 1;
				fTimer = m_pSystem->GetDeltaTime(uClock);
				routes[j] %= listListVectors[j].size();
			}
			
		}
		
		matrix4 m4Model = glm::translate(m4Offset, v3CurrentPos);

		//draw spheres
		m_pMeshMngr->AddSphereToRenderList(m4Model * glm::scale(vector3(0.1)), C_WHITE);
	}
	/*
	vector3 start;
	vector3 end;
	static uint route = 0;

	if (route < listListVectors[0].size() - 1)
	{
		start = listListVectors[0][route];
		end = listListVectors[0][route + 1];
	}
	else
	{
		start = listListVectors[0][listListVectors[0].size() - 1];
		end = listListVectors[0][0];
	}

	float percentage = static_cast<float>(MapValue(fTimer, 0.0, 2.0, 0.0, 1.0));
	vector3 v3CurrentPos2 = glm::lerp(start, end, percentage);

	if (percentage >= 1.0f)
	{
		route++;
		fTimer = m_pSystem->GetDeltaTime(uClock);
		route %= listListVectors[0].size();
	}
	
	matrix4 m4Model2 = glm::translate(m4Offset, v3CurrentPos2);
	m_pMesh->Render(m4Projection, m4View, m4Model2);
	*/
	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();
	
	//draw gui
	DrawGUI();
	
	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	//release GUI
	ShutdownGUI();
}