#pragma once
#include <vector>
#include <stack>
#include "MyVertex.h"
//#include "AdjList.h"


class Graph
{
public:
	Graph();
	~Graph();
	void SetGraph(int**, int, int, int, int, int, int);// will take in the already set maze data for use in path finding 
	void FillList(int, int);
	void PathFinding(stack<MyVertex*>&, int, int, int, int);
	vector<vector<MyVertex*>> vertices;// two dimensional array to keep track of the vertices in the graph
private:
	stack<MyVertex*> openList;
};

