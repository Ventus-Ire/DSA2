#include "Maze.h"



Maze::Maze()
{
}


Maze::~Maze()
{
}
//Fill the maze with data 
//Attempted to initialize the maze manually
bool Maze::SetMaze( int width, int height)
{
	mazeData = new int*[4];
	for (int i = 0; i < 4; ++i)
	{
		mazeData[i] = new int[4];
	}

	mazeData[0][0] = 1;
	mazeData[0][1] = 1;
	mazeData[0][2] = 1;
	mazeData[0][3] = 1;

	mazeData[1][0] = 0;
	mazeData[1][1] = 0;
	mazeData[1][2] = 10;
	mazeData[1][3] = 1;

	mazeData[2][0] = 0;
	mazeData[2][1] = 0;
	mazeData[2][2] = 0;
	mazeData[2][3] = 1;

	mazeData[3][0] = 0;
	mazeData[3][1] = 0;
	mazeData[3][2] = 1;
	mazeData[3][3] = 1;
	mWidth = width;
	mHeight = height;

	// return false if it fails to set the maze correctly, for instance if the width and height are 0 or negative
	if (mWidth <= 0 && mHeight <= 0)
		return false;
	else
	{
		// if the maze data has been saved correctly  pass through the data to be set in the graph then do the pathfinding at the beginning of GetNextPosition
		//graph->SetGraph(mazeData, mWidth, mHeight, startX, startY, endX, endY);
		return true;
	}
}

int** Maze::GetMaze(int & width, int & height)
{
	// if the maze data is not set returns NULL ptr
	if (mazeData == NULL)
		return NULL;
	else
	{
		width = mWidth;
		height = mHeight;
		return mazeData;
	}
}

bool Maze::GetNextPosition(int & xpos, int & ypos)
{
	// if pathfinding has not been done yet do path finding and set up the correct path in an array
	if (pathFinding == false)
	{
		graph->SetGraph(mazeData, mWidth, mHeight, startX, startY, endX, endY);

		graph->PathFinding(pathData, startX, startY, endX, endY);
		pathFinding = true;
	}

	// check to see if there is anymore data in the array or if they are at the end of the path
	xpos = (*pathData.top()).xPos;
	ypos = (*pathData.top()).yPos;
	pathData.pop();

	// returns true if there are still mores steps to take, if there are no more (as in it has reached the end) return false
	if (xpos == endX && ypos == endY)
	{
		return false;
	}
	else
		return true;
}

bool Maze::SetStart(int xpos, int ypos)
{
	if (mazeData == NULL)
	{
		startX = NULL;
		startY = NULL;
		return false;
		//cout
	}
	else
	{
		//GetStart(xpos, ypos);
		startX = xpos;
		startY = ypos;
		return true;
	}
}

bool Maze::GetStart(int & xpos, int & ypos)
{
	// check to see if the values have been saved yet or not
	if (startX == NULL || startY == NULL)
	{
		return false;
	}
	else
	{
		xpos = startX;
		ypos = startY;
		return true;
	}
}

bool Maze::SetEnd(int xpos, int ypos)
{
	if (mazeData == NULL)
	{
		endX = NULL;
		endY = NULL;
		return false;
	}
	else
	{
		endX = xpos;
		endY = ypos;
		return true;
	}
}

bool Maze::GetEnd(int & xpos, int & ypos)
{
	// check to see if the values have been saved yet or not
	if (endX == NULL || endY == NULL)
	{
		return false;
	}
	else
	{
		xpos = endX;
		ypos = endY;
		return true;
	}
}
