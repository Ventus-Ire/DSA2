//#include "stdafx.h"
#include "Graph.h"
#include <list>

Graph::Graph()
{
}


Graph::~Graph()
{
}

// read through the maze data and find any spaces that would be considered a vertex. 
// create a vertex and place it in the 
void Graph::SetGraph(int **maze, int width, int height, int startX, int startY, int endX, int endY)
{

	for (int x = 0; x< width; x++)
	{
		vector<MyVertex*> temp;// a vector for each row, reset at the start of each new row of data
		for (int y = 0; y < height; y++)
		{
			// check to see if this spot is a 0 or 1
			if (maze[x][y] == 0)// a vertex needs to be created here
			{
				// if the value is 1 (AKA it's a wall space) make the vertex at that spot in the array null
				MyVertex* vert = new MyVertex(x, y, maze[x][y]);
				(*vert).visited = true;
				temp.push_back(vert);
			}
			else
			{
				MyVertex* vert = new MyVertex(x, y, maze[x][y]);

				// calculate the distance this vertex is from the starting point that is the lowestcost value
				(*vert).lowestCost = abs((startX - x) + (startY - y) + maze[x][y]);
				// calculate the vertex's heuristic using the end point
				(*vert).heuristic = abs((endX - x) + (endY - y));
				(*vert).score = (*vert).heuristic + (*vert).lowestCost;

				temp.push_back(vert);
			}
		}
		vertices.push_back(temp);
	}
	FillList(width, height);
}

// use the vertices generated into the vertices array to determine the adjacency matrix
void Graph::FillList(int w, int h)
{
	for (size_t x = 0; x < w; x++)
	{
		for (size_t y = 0; y < h; y++)
		{

			// check each vertex around this one, if that vertex's value is 0 add it to the list
			// make sure it isn't trying to add spaces that don't exist such as x = -1 or y = height + 1
			if (x != (w - 1))
			{
				if ((*vertices[x + 1][y]).value != 0)
				{
					(*vertices[x][y]).adjacent.push_back(vertices[x + 1][y]);
				}
			}
			if (x != 0)
			{
				if ((*vertices[x - 1][y]).value != 0)
				{
					(*vertices[x][y]).adjacent.push_back(vertices[x - 1][y]);
				}
			}
			if (y != (h - 1))
			{
				if ((*vertices[x][y + 1]).value != 0)
				{
					(*vertices[x][y]).adjacent.push_back(vertices[x][y + 1]);
				}
			}
			if (y != 0)
			{
				if ((*vertices[x][y - 1]).value != 0)
				{
					(*vertices[x][y]).adjacent.push_back(vertices[x][y - 1]);
				}
			}
		}
	}
}

void Graph::PathFinding(stack<MyVertex*>& pathData, int startX, int startY, int endX, int endY)
{
	// counter to keep track of how many moves the maze runner has made up to this point. this will be added into the score if it is greater than the lowest cost of a vertex
	int moveCount = 0;
	// place the starting space in the open list
	MyVertex* currentSpace = vertices[startX][startY];
	openList.push(currentSpace);// picking starting vertex and pushing it onto the stack

	while (!openList.empty())// while stack is not empty
	{
		// loop through the currentspace's adjacency list and find if a space has been visited before, if it has remove it
		for (size_t i = 0; i < currentSpace->adjacent.size(); i++)
		{
			if (currentSpace->adjacent[i]->visited == true)
			{
				(*currentSpace).adjacent.erase((*currentSpace).adjacent.begin() + i);
			}
		}
		// see if the current tile has any non-visited spaces, if it doesn't remove it from the stack and set current space to the space in the stack after it
		if (currentSpace->adjacent.size() == 0)
		{
			// remove this space from the stack and set current space to the space it was previously at
			openList.pop();
			currentSpace = openList.top();
		}
		else
		{
			// check adjacent tiles and pick the lowest one that hasn't been visited yet
			MyVertex* temp = (*openList.top()).adjacent[0];
			for (MyVertex* v : currentSpace->adjacent)
			{
				// first check if the movecount is greater than the v's lowest cost. if it is make that the vertex's lowest cost 
				int lowestCost = 0;
				if ((*v).lowestCost < moveCount)
				{
					lowestCost = moveCount;
					(*v).score = lowestCost + (*v).heuristic;
				}

				if ((*v).score <= (*temp).score && (*v).visited == false)// find which space is the lowest and IF there is a tie pick the tile that has the lower heuristic
				{
					temp = v;
				}
			}
			// mark the adjacent as visited and push it onto the stack as the new currentspace
			currentSpace = temp;
			currentSpace->visited = true;
			openList.push(currentSpace);
		}

		// check if the current space is the end of the maze. If so set pathData to the values in the openlist and leave the loop
		if ((*currentSpace).xPos == endX && (*currentSpace).yPos == endY)
		{
			do
			{
				pathData.push(openList.top());
				openList.pop();
			} while (!openList.empty());
			break;
		}
	}
}