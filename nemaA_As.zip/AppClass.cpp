#include "AppClass.h"
#include "Maze.h"
void Application::InitVariables(void)
{
	///Visually create the maze using black cubes as the path
	///White cubes as the walls and a red cube indicating a not viable path
	///Blues indiate the start and end positions
	//init the mesh
	m_pMesh = new MyMesh();
	//m_pMesh->GenerateCube(1.0f, C_WHITE);
	m_pMesh->GenerateCube(1.0f, C_WHITE);
	
	mesh2 = new MyMesh();
	mesh2->GenerateCube(1.0f, C_WHITE);
	
	mesh3 = new MyMesh();
	mesh3->GenerateCube(1.0f, C_BLUE);
	
	mesh4 = new MyMesh();
	mesh4->GenerateCube(1.0f, C_WHITE);
	
	mesh5 = new MyMesh();
	mesh5->GenerateCube(1.0f, C_WHITE);

	mesh6 = new MyMesh();
	mesh6->GenerateCube(1.0f, C_WHITE);

	mesh7 = new MyMesh();
	mesh7->GenerateCube(1.0f, C_WHITE);

	mesh8 = new MyMesh();
	mesh8->GenerateCube(1.0f, C_WHITE);

	mesh9 = new MyMesh();
	mesh9->GenerateCube(1.0f, C_RED);

	mesh10 = new MyMesh();
	mesh10->GenerateCube(1.0f, C_BLUE);

	mesh11 = new MyMesh();
	mesh11->GenerateCube(1.0f, C_BLACK);

	mesh12 = new MyMesh();
	mesh12->GenerateCube(1.0f, C_BLACK);

	mesh13 = new MyMesh();
	mesh13->GenerateCube(1.0f, C_BLACK);

	mesh14 = new MyMesh();
	mesh14->GenerateCube(1.0f, C_BLACK);

	mesh15 = new MyMesh();
	mesh15->GenerateCube(1.0f, C_BLACK);

	mesh16 = new MyMesh();
	mesh16->GenerateCube(1.0f, C_BLACK);

	//The Green sphere indicates that it has received the starting location created by the graph
	mesh17 = new MyMesh();
	mesh17->GenerateSphere(1.0f, 5, C_GREEN);
	//The Red sphere indicates the path that the green sphere should have taken
	mesh18 = new MyMesh();
	mesh18->GenerateSphere(1.0f, 5, C_WHITE);

	//Begin the creation of the maze
	maze = new Maze();
	maze->SetMaze(4, 4);
	maze->SetStart(0, 0);
	maze->SetEnd(3, 4);

	///For some reason, completing the path of the maze crashes the program
	///It sets the start of the maze
	//maze->GetNextPosition(maze->startX, maze->startY);
	int positionX = maze->startX;
	int positionY = maze->startY;


}
void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the arcball active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();
}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();


	//Indicates the path of the WHITE sphere, this is the route the a* should take
	static vector<vector3> stops;
	vector3 v3CurrentPos;
	vector3 start;
	vector3 end;
	
	static bool init = false;
	if (!init)
	{
		stops.push_back(vector3(-3.0f, 6.0f, 0.0f));
		stops.push_back(vector3(-1.0f, 6.0f, 0.0f));
		stops.push_back(vector3(1.0f, 6.0f, 0.0f));
		stops.push_back(vector3(3.0f, 6.0f, 0.0f));
		stops.push_back(vector3(3.0f, 4.0f, 0.0f));
		stops.push_back(vector3(3.0f, 2.0f, 0.0f));
		stops.push_back(vector3(3.0f, 0.0f, 0.0f));
		stops.push_back(vector3(1.0f, 0.0f, 0.0f));
		init = true;
	}


	matrix4 m4View = m_pCameraMngr->GetViewMatrix();
	matrix4 m4Projection = m_pCameraMngr->GetProjectionMatrix();
	static float value = 0.0f;
	
	matrix4 m4Scale = glm::scale(IDENTITY_M4, vector3(1.0f,1.0f,1.0f));
	//Visually create the graph
	matrix4 m4Translate = glm::translate(IDENTITY_M4, vector3(-3.0f + value, 0.0f, -1.0f));
	matrix4 t2 = glm::translate(IDENTITY_M4, vector3(-1.0f + value, 0.0f, -1.0f));
	matrix4 t3 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 0.0f, -1.0f));
	matrix4 t13 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 0.0f, -1.0f));

	matrix4 t4 = glm::translate(IDENTITY_M4, vector3(-3.0f + value, 2.0f, -1.0f));
	matrix4 t5 = glm::translate(IDENTITY_M4, vector3(-1.0f + value, 2.0f, -1.0f));
	matrix4 t6 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 2.0f, -1.0f));
	matrix4 t14 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 2.0f, -1.0f));

	matrix4 t7 = glm::translate(IDENTITY_M4, vector3(-3.0f + value, 4.0f, -1.0f));
	matrix4 t8 = glm::translate(IDENTITY_M4, vector3(-1.0f + value, 4.0f, -1.0f));
	matrix4 t9 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 4.0f, -1.0f));
	matrix4 t15 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 4.0f, -1.0f));

	matrix4 t10 = glm::translate(IDENTITY_M4, vector3(-3.0f + value, 6.0f, -1.0f));
	matrix4 t11 = glm::translate(IDENTITY_M4, vector3(-1.0f + value, 6.0f, -1.0f));
	matrix4 t12 = glm::translate(IDENTITY_M4, vector3(1.0f + value, 6.0f, -1.0f));
	matrix4 t16 = glm::translate(IDENTITY_M4, vector3(3.0f + value, 6.0f, -1.0f));

	/*
	Graph should have a value as follows
	1, 1, 1,  1
	0, 0, 10, 1
	0, 0, 0,  1
	0, 0, 1,  1
	
	indicating that the path that the green sphere takes should be all 1s going to the right then downwards
	
	*/

	//matrix4 t17 = glm::translate(IDENTITY_M4, vector3((float)maze->graph->vertices[0][0]->xPos - 3.0f, (float)maze->graph->vertices[0][0]->yPos, 0.0f));
	
	//Translate the green sphere to the starting location
	matrix4 t17 = glm::translate(IDENTITY_M4, vector3((float)maze->startX - 3.0f, (float)maze->startY + 6.0f, 0.0f));

	//Get a timer
	static double fTimer = 0.0;	//store the new timer
	static uint uClock = m_pSystem->GenClock(); //generate a new clock for that timer
	fTimer += m_pSystem->GetDeltaTime(uClock); //get the delta time for that timer
	//For the white sphere
	static uint route = 0;
	if (route < stops.size() - 1)
	{
		start = stops[route];
		end = stops[route + 1];
	}
	else
	{
		start = stops[stops.size() - 1];
		end = start;
	}

	float percentage = static_cast<float>(MapValue(fTimer, 0.0, 1.5, 0.0, 1.0));
	v3CurrentPos = glm::lerp(start, end, percentage);

	if (percentage >= 1.0f)
	{
		route++;
		fTimer = m_pSystem->GetDeltaTime(uClock);
		route %= stops.size();
	}

	matrix4 path = m4Scale * glm::translate(v3CurrentPos);

	//Get the matrix
	//matrix4 m4Model = m4Translate * m4Scale;
	matrix4 m4Model = m4Scale * m4Translate;
	matrix4 m2 = m4Scale * t2;
	matrix4 m3 = m4Scale * t3;
	matrix4 m4 = m4Scale * t4;
	matrix4 m5 = m4Scale * t5;
	matrix4 m6 = m4Scale * t6;
	matrix4 m7 = m4Scale * t7;
	matrix4 m8 = m4Scale * t8;
	matrix4 m9 = m4Scale * t9;
	matrix4 m10 = m4Scale * t10;
	matrix4 m11 = m4Scale * t11;
	matrix4 m12 = m4Scale * t12;
	matrix4 m13 = m4Scale * t13;
	matrix4 m14 = m4Scale * t14;
	matrix4 m15 = m4Scale * t15;
	matrix4 m16 = m4Scale * t16;
	matrix4 m17 = m4Scale * t17;

	//Render the meshes
	m_pMesh->Render(m4Projection, m4View, m4Model);
	mesh2->Render(m4Projection, m4View, m2);
	mesh3->Render(m4Projection, m4View, m3);
	mesh4->Render(m4Projection, m4View, m4);
	mesh5->Render(m4Projection, m4View, m5);
	mesh6->Render(m4Projection, m4View, m6);
	mesh7->Render(m4Projection, m4View, m7);
	mesh8->Render(m4Projection, m4View, m8);
	mesh9->Render(m4Projection, m4View, m9);
	mesh10->Render(m4Projection, m4View, m10);
	mesh11->Render(m4Projection, m4View, m11);
	mesh12->Render(m4Projection, m4View, m12);
	mesh13->Render(m4Projection, m4View, m13);
	mesh14->Render(m4Projection, m4View, m14);
	mesh15->Render(m4Projection, m4View, m15);
	mesh16->Render(m4Projection, m4View, m16);
	mesh17->Render(m4Projection, m4View, m17);
	mesh18->Render(m4Projection, m4View, path);
	
	// draw a skybox
	m_pMeshMngr->AddSkyboxToRenderList();
	
	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();
	
	//draw gui
	DrawGUI();
	
	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	SafeDelete(m_pMesh);

	//release GUI
	ShutdownGUI();
}