#include "MyVertex.h"



MyVertex::MyVertex()
{
}

MyVertex::MyVertex(int xP, int yP, int val)
{
	xPos = xP;
	yPos = yP;
	value = val;
	visited = false;
}

MyVertex::~MyVertex()
{
}
