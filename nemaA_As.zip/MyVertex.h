#pragma once
#include <vector>
using namespace std;


class MyVertex
{
public:
	MyVertex();
	MyVertex(int, int, int);
	~MyVertex();

	int xPos;
	int yPos;
	int value;// is the vertex a 0 or 1?
	int heuristic;
	int lowestCost;// used in calculating pathfinding
	int score;// used during path finding calculations
	bool visited;
	//Vertex* adjacent;// array of adjacent vertices
	vector<MyVertex*> adjacent;


};

