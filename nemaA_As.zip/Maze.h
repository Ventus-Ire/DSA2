#pragma once
#include "Graph.h"
#include <stack>


//int num1 = 0;



class Maze
{

public:
	Maze();
	~Maze();
	
	int startX = 0;
	int startY = 0;// variables for SetStart and GetStart
	Graph* graph = new Graph();// graph variable to access pathfinding things


	//int nextX, nextY;// variables for GetNextPosition

	bool SetMaze(int width, int height);

	int** GetMaze(int& width, int& height);

	bool GetNextPosition(int& xpos, int& ypos);

	bool SetStart(int xpos, int ypos);

	bool GetStart(int& xpos, int& ypos);

	bool SetEnd(int xpos, int ypos);

	bool GetEnd(int& xpos, int& ypos);
private:
	int mWidth;
	int mHeight;
	int **mazeData;

	//int trueMaze = mazeData[4][4] = { { 1, 1, 1, 1 },{ 0, 0, 10, 1 },{ 0, 0, 0, 1 },{ 0, 0, 0, 1 } };
	stack<MyVertex*> pathData;// the pathfinding will store the solution in here
	int endX = 4;
	int endY = 4;// variables for SetEnd and GetEnd
	
	bool pathFinding = false;// bool to track if the pathfinding has been completed yet
	

};

